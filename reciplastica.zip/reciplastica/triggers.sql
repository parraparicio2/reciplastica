/*
SQLyog Ultimate v9.02 
MySQL - 5.1.54-community-log : Database - reciplastica
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`reciplastica` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `reciplastica`;

/* Trigger structure for table `carga_inventario` */

DELIMITER $$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'127.0.0.1' */ /*!50003 TRIGGER `trg_eliminar_carga_inventario` BEFORE DELETE ON `carga_inventario` FOR EACH ROW BEGIN
       delete from carga_productos where nro_carga = old.nro_carga;
    END */$$


DELIMITER ;

/* Trigger structure for table `carga_productos` */

DELIMITER $$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'127.0.0.1' */ /*!50003 TRIGGER `trg_cargar_inventario` AFTER INSERT ON `carga_productos` FOR EACH ROW BEGIN
        update productos a 
           set a.existencia = a.existencia + new.cantidad
       where a.codigo_producto = new.codigo_producto; 
    END */$$


DELIMITER ;

/* Trigger structure for table `carga_productos` */

DELIMITER $$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'127.0.0.1' */ /*!50003 TRIGGER `trg_restar_productos` AFTER DELETE ON `carga_productos` FOR EACH ROW BEGIN
        
        update productos a 
           set a.existencia = a.existencia - old.cantidad
       where a.codigo_producto = old.codigo_producto; 
    END */$$


DELIMITER ;

/* Trigger structure for table `detalle_factura` */

DELIMITER $$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'127.0.0.1' */ /*!50003 TRIGGER `trg_restar_inventario` AFTER INSERT ON `detalle_factura` FOR EACH ROW begin
    
    declare v_cantidad integer;
    
     select b.existencia - new.cantidad into v_cantidad
                       from productos b
                      where b.codigo_producto = new.codigo_producto;
                      
    if v_cantidad < 0 then
       insert into productos(codigo_producto) values(null); 	
    end if;                   
                                                   
    update productos a 
       set a.existencia = a.existencia - new.cantidad
     where a.codigo_producto = new.codigo_producto;   
          
  
    end */$$


DELIMITER ;

/* Trigger structure for table `detalle_factura` */

DELIMITER $$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'127.0.0.1' */ /*!50003 TRIGGER `trg_actualizar_inventario` BEFORE UPDATE ON `detalle_factura` FOR EACH ROW begin
       declare v_cantidad integer;
    
     select b.existencia - new.cantidad + old.cantidad into v_cantidad
                       from productos b
                      where b.codigo_producto = new.codigo_producto;
                      
    if v_cantidad < 0 then
       insert into productos(codigo_producto) values(null); 	
    end if;                   
                                                   
    update productos a 
       set a.existencia = v_cantidad 
     where a.codigo_producto = new.codigo_producto;   
          
 
    end */$$


DELIMITER ;

/* Trigger structure for table `detalle_factura` */

DELIMITER $$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'127.0.0.1' */ /*!50003 TRIGGER `trg_sumar_eliminado` AFTER DELETE ON `detalle_factura` FOR EACH ROW begin
       
       update productos a
          set a.existencia = a.existencia + old.cantidad
       where a.codigo_producto = old.codigo_producto;   
    end */$$


DELIMITER ;

/* Trigger structure for table `detalle_insumo` */

DELIMITER $$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'127.0.0.1' */ /*!50003 TRIGGER `trg_incrementar_insumos` AFTER INSERT ON `detalle_insumo` FOR EACH ROW BEGIN
       update productos a 
           set a.existencia = a.existencia + new.cantidad
       where a.codigo_producto = new.codigo_producto;    
    END */$$


DELIMITER ;

/* Trigger structure for table `detalle_insumo` */

DELIMITER $$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'127.0.0.1' */ /*!50003 TRIGGER `trg_eliminar_insumos` BEFORE DELETE ON `detalle_insumo` FOR EACH ROW BEGIN
       update productos a
          set a.existencia = a.existencia - old.cantidad 
        where a.codigo_producto = old.codigo_producto;   
    END */$$


DELIMITER ;

/* Trigger structure for table `factura` */

DELIMITER $$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'127.0.0.1' */ /*!50003 TRIGGER `trg_eliminar_factura` BEFORE DELETE ON `factura` FOR EACH ROW BEGIN
       delete from detalle_factura where numero = old.numero;
    END */$$


DELIMITER ;

/* Trigger structure for table `insumos` */

DELIMITER $$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'127.0.0.1' */ /*!50003 TRIGGER `trg_eliminar_insumo_principal` BEFORE DELETE ON `insumos` FOR EACH ROW BEGIN
    
       delete 
         from detalle_insumo  
        where codigo_insumo = old.codigo_insumo;    
    END */$$


DELIMITER ;

/* Trigger structure for table `productos` */

DELIMITER $$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'127.0.0.1' */ /*!50003 TRIGGER `trg_actualizar_precios` AFTER UPDATE ON `productos` FOR EACH ROW BEGIN
       if new.precio <> old.precio then
          insert into historico_precios(codigo_producto, precio_nuevo, precio_anterior, fecha, hora)
               values (new.codigo_producto, new.precio, old.precio, current_date, current_time);
       end if;
    END */$$


DELIMITER ;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
