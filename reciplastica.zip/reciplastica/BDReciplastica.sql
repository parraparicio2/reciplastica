/*
SQLyog Ultimate v9.02 
MySQL - 5.1.54-community-log : Database - reciplastica
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`reciplastica` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `reciplastica`;

/*Table structure for table `auditoria` */

DROP TABLE IF EXISTS `auditoria`;

CREATE TABLE `auditoria` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `login` varchar(20) DEFAULT NULL,
  `operacion` varchar(20) DEFAULT NULL,
  `tabla` varchar(20) DEFAULT NULL,
  `descripcion` varchar(100) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `hora` time DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=311 DEFAULT CHARSET=latin1;

/*Table structure for table `carga_inventario` */

DROP TABLE IF EXISTS `carga_inventario`;

CREATE TABLE `carga_inventario` (
  `nro_carga` bigint(20) NOT NULL AUTO_INCREMENT,
  `fecha` date DEFAULT NULL,
  `responsable` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`nro_carga`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Table structure for table `carga_productos` */

DROP TABLE IF EXISTS `carga_productos`;

CREATE TABLE `carga_productos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nro_carga` bigint(20) NOT NULL,
  `codigo_producto` varchar(15) NOT NULL,
  `cantidad` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `codigo_producto` (`codigo_producto`),
  KEY `nro_carga` (`nro_carga`),
  CONSTRAINT `carga_productos_ibfk_1` FOREIGN KEY (`codigo_producto`) REFERENCES `productos` (`codigo_producto`) ON UPDATE CASCADE,
  CONSTRAINT `carga_productos_ibfk_2` FOREIGN KEY (`nro_carga`) REFERENCES `carga_inventario` (`nro_carga`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

/*Table structure for table `clientes` */

DROP TABLE IF EXISTS `clientes`;

CREATE TABLE `clientes` (
  `codigo_c` varchar(15) NOT NULL,
  `nombre` varchar(50) DEFAULT NULL,
  `cedula_rif` varchar(15) DEFAULT NULL,
  `direccion` varchar(160) DEFAULT NULL,
  `telefono` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`codigo_c`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `detalle_factura` */

DROP TABLE IF EXISTS `detalle_factura`;

CREATE TABLE `detalle_factura` (
  `linea` int(11) NOT NULL AUTO_INCREMENT,
  `codigo_producto` varchar(15) NOT NULL,
  `numero` int(11) NOT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `valor_venta` decimal(10,2) DEFAULT NULL,
  `subtotal` decimal(10,2) DEFAULT NULL,
  `iva` decimal(10,2) DEFAULT NULL,
  `total_iva` decimal(10,2) DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`linea`),
  KEY `numero` (`numero`),
  KEY `codigo_producto` (`codigo_producto`),
  CONSTRAINT `detalle_factura_ibfk_1` FOREIGN KEY (`numero`) REFERENCES `factura` (`numero`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `detalle_factura_ibfk_2` FOREIGN KEY (`codigo_producto`) REFERENCES `productos` (`codigo_producto`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=latin1;

/*Table structure for table `detalle_insumo` */

DROP TABLE IF EXISTS `detalle_insumo`;

CREATE TABLE `detalle_insumo` (
  `linea` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `codigo_producto` varchar(15) NOT NULL,
  `codigo_insumo` int(11) NOT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `precio` decimal(10,2) DEFAULT NULL,
  `subtotal` decimal(10,2) DEFAULT NULL,
  `iva` decimal(10,2) DEFAULT NULL,
  `total_iva` decimal(10,2) DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`linea`),
  KEY `codigo_insumo` (`codigo_insumo`),
  KEY `codigo_producto` (`codigo_producto`),
  CONSTRAINT `detalle_insumo_ibfk_1` FOREIGN KEY (`codigo_insumo`) REFERENCES `insumos` (`codigo_insumo`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `detalle_insumo_ibfk_2` FOREIGN KEY (`codigo_producto`) REFERENCES `productos` (`codigo_producto`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

/*Table structure for table `factura` */

DROP TABLE IF EXISTS `factura`;

CREATE TABLE `factura` (
  `numero` int(11) NOT NULL AUTO_INCREMENT,
  `codigo_c` varchar(15) NOT NULL,
  `fecha` date DEFAULT NULL,
  `temporal` char(1) DEFAULT NULL,
  PRIMARY KEY (`numero`),
  KEY `codigo_c` (`codigo_c`),
  CONSTRAINT `factura_ibfk_1` FOREIGN KEY (`codigo_c`) REFERENCES `clientes` (`codigo_c`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

/*Table structure for table `historico_precios` */

DROP TABLE IF EXISTS `historico_precios`;

CREATE TABLE `historico_precios` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `codigo_producto` varchar(15) NOT NULL,
  `precio_anterior` decimal(10,2) DEFAULT NULL,
  `precio_nuevo` decimal(10,2) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `hora` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `codigo_producto` (`codigo_producto`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Table structure for table `insumos` */

DROP TABLE IF EXISTS `insumos`;

CREATE TABLE `insumos` (
  `codigo_insumo` int(11) NOT NULL AUTO_INCREMENT,
  `nro_factura_prov` varchar(15) DEFAULT NULL,
  `codigo_prov` varchar(15) NOT NULL,
  `observaciones` text,
  `fecha` date DEFAULT NULL,
  PRIMARY KEY (`codigo_insumo`),
  KEY `codigo_prov` (`codigo_prov`),
  CONSTRAINT `insumos_ibfk_1` FOREIGN KEY (`codigo_prov`) REFERENCES `proveedores` (`codigo_prov`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Table structure for table `iva` */

DROP TABLE IF EXISTS `iva`;

CREATE TABLE `iva` (
  `valor` decimal(10,2) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Table structure for table `productos` */

DROP TABLE IF EXISTS `productos`;

CREATE TABLE `productos` (
  `codigo_producto` varchar(15) NOT NULL,
  `descripcion` varchar(100) DEFAULT NULL,
  `existencia` bigint(20) DEFAULT NULL,
  `precio` decimal(10,2) DEFAULT NULL,
  `foto` longblob,
  PRIMARY KEY (`codigo_producto`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `proveedores` */

DROP TABLE IF EXISTS `proveedores`;

CREATE TABLE `proveedores` (
  `codigo_prov` varchar(15) NOT NULL,
  `nombre` varchar(50) DEFAULT NULL,
  `direccion` varchar(160) DEFAULT NULL,
  `rif` varchar(15) DEFAULT NULL,
  `telefono` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`codigo_prov`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `usuarios` */

DROP TABLE IF EXISTS `usuarios`;

CREATE TABLE `usuarios` (
  `login` varchar(20) NOT NULL,
  `tipo` char(1) DEFAULT NULL,
  `clave` varchar(20) DEFAULT NULL,
  `nombre` varchar(40) NOT NULL,
  PRIMARY KEY (`login`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/* Trigger structure for table `carga_inventario` */

DELIMITER $$

/*!50003 DROP TRIGGER*//*!50032 IF EXISTS */ /*!50003 `trg_eliminar_carga_inventario` */$$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'127.0.0.1' */ /*!50003 TRIGGER `trg_eliminar_carga_inventario` BEFORE DELETE ON `carga_inventario` FOR EACH ROW BEGIN
       delete from carga_productos where nro_carga = old.nro_carga;
    END */$$


DELIMITER ;

/* Trigger structure for table `carga_productos` */

DELIMITER $$

/*!50003 DROP TRIGGER*//*!50032 IF EXISTS */ /*!50003 `trg_cargar_inventario` */$$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'127.0.0.1' */ /*!50003 TRIGGER `trg_cargar_inventario` AFTER INSERT ON `carga_productos` FOR EACH ROW BEGIN
        update productos a 
           set a.existencia = a.existencia + new.cantidad
       where a.codigo_producto = new.codigo_producto; 
    END */$$


DELIMITER ;

/* Trigger structure for table `carga_productos` */

DELIMITER $$

/*!50003 DROP TRIGGER*//*!50032 IF EXISTS */ /*!50003 `trg_restar_productos` */$$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'127.0.0.1' */ /*!50003 TRIGGER `trg_restar_productos` AFTER DELETE ON `carga_productos` FOR EACH ROW BEGIN
        
        update productos a 
           set a.existencia = a.existencia - old.cantidad
       where a.codigo_producto = old.codigo_producto; 
    END */$$


DELIMITER ;

/* Trigger structure for table `detalle_factura` */

DELIMITER $$

/*!50003 DROP TRIGGER*//*!50032 IF EXISTS */ /*!50003 `trg_restar_inventario` */$$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'127.0.0.1' */ /*!50003 TRIGGER `trg_restar_inventario` AFTER INSERT ON `detalle_factura` FOR EACH ROW begin
    
    declare v_cantidad integer;
    
     select b.existencia - new.cantidad into v_cantidad
                       from productos b
                      where b.codigo_producto = new.codigo_producto;
                      
    if v_cantidad < 0 then
       insert into productos(codigo_producto) values(null); 	
    end if;                   
                                                   
    update productos a 
       set a.existencia = a.existencia - new.cantidad
     where a.codigo_producto = new.codigo_producto;   
          
  
    end */$$


DELIMITER ;

/* Trigger structure for table `detalle_factura` */

DELIMITER $$

/*!50003 DROP TRIGGER*//*!50032 IF EXISTS */ /*!50003 `trg_actualizar_inventario` */$$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'127.0.0.1' */ /*!50003 TRIGGER `trg_actualizar_inventario` BEFORE UPDATE ON `detalle_factura` FOR EACH ROW begin
       declare v_cantidad integer;
    
     select b.existencia - new.cantidad + old.cantidad into v_cantidad
                       from productos b
                      where b.codigo_producto = new.codigo_producto;
                      
    if v_cantidad < 0 then
       insert into productos(codigo_producto) values(null); 	
    end if;                   
                                                   
    update productos a 
       set a.existencia = v_cantidad 
     where a.codigo_producto = new.codigo_producto;   
          
 
    end */$$


DELIMITER ;

/* Trigger structure for table `detalle_factura` */

DELIMITER $$

/*!50003 DROP TRIGGER*//*!50032 IF EXISTS */ /*!50003 `trg_sumar_eliminado` */$$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'127.0.0.1' */ /*!50003 TRIGGER `trg_sumar_eliminado` AFTER DELETE ON `detalle_factura` FOR EACH ROW begin
       
       update productos a
          set a.existencia = a.existencia + old.cantidad
       where a.codigo_producto = old.codigo_producto;   
    end */$$


DELIMITER ;

/* Trigger structure for table `detalle_insumo` */

DELIMITER $$

/*!50003 DROP TRIGGER*//*!50032 IF EXISTS */ /*!50003 `trg_incrementar_insumos` */$$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'127.0.0.1' */ /*!50003 TRIGGER `trg_incrementar_insumos` AFTER INSERT ON `detalle_insumo` FOR EACH ROW BEGIN
       update productos a 
           set a.existencia = a.existencia + new.cantidad
       where a.codigo_producto = new.codigo_producto;    
    END */$$


DELIMITER ;

/* Trigger structure for table `detalle_insumo` */

DELIMITER $$

/*!50003 DROP TRIGGER*//*!50032 IF EXISTS */ /*!50003 `trg_eliminar_insumos` */$$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'127.0.0.1' */ /*!50003 TRIGGER `trg_eliminar_insumos` BEFORE DELETE ON `detalle_insumo` FOR EACH ROW BEGIN
       update productos a
          set a.existencia = a.existencia - old.cantidad 
        where a.codigo_producto = old.codigo_producto;   
    END */$$


DELIMITER ;

/* Trigger structure for table `factura` */

DELIMITER $$

/*!50003 DROP TRIGGER*//*!50032 IF EXISTS */ /*!50003 `trg_eliminar_factura` */$$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'127.0.0.1' */ /*!50003 TRIGGER `trg_eliminar_factura` BEFORE DELETE ON `factura` FOR EACH ROW BEGIN
       delete from detalle_factura where numero = old.numero;
    END */$$


DELIMITER ;

/* Trigger structure for table `insumos` */

DELIMITER $$

/*!50003 DROP TRIGGER*//*!50032 IF EXISTS */ /*!50003 `trg_eliminar_insumo_principal` */$$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'127.0.0.1' */ /*!50003 TRIGGER `trg_eliminar_insumo_principal` BEFORE DELETE ON `insumos` FOR EACH ROW BEGIN
    
       delete 
         from detalle_insumo  
        where codigo_insumo = old.codigo_insumo;    
    END */$$


DELIMITER ;

/* Trigger structure for table `productos` */

DELIMITER $$

/*!50003 DROP TRIGGER*//*!50032 IF EXISTS */ /*!50003 `trg_actualizar_precios` */$$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'127.0.0.1' */ /*!50003 TRIGGER `trg_actualizar_precios` AFTER UPDATE ON `productos` FOR EACH ROW BEGIN
       if new.precio <> old.precio then
          insert into historico_precios(codigo_producto, precio_nuevo, precio_anterior, fecha, hora)
               values (new.codigo_producto, new.precio, old.precio, current_date, current_time);
       end if;
    END */$$


DELIMITER ;

insert into usuarios(login, clave, nombre, tipo) values('administrador','123','administrador','A');
insert into usuarios(login, clave, nombre, tipo) values('usuario','123','usuario','U');
INSERT INTO iva (valor)VALUES(12);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
